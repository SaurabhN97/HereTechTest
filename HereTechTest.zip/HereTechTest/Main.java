import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.regex.Pattern;

public class Main {
    public static void main(String[] args) throws IOException {
        String[] names = {"Mark Zuckerberg", "Will Smith", "William Gates", "Warren Buffet"};

        InputStreamReader inputStreamReader = new InputStreamReader(System.in);
        BufferedReader bufferedReader = new BufferedReader(inputStreamReader);

        System.out.println("Search...");
        String str = bufferedReader.readLine();
        str = str.trim().toUpperCase();

        for (int i = 0; i < names.length; i++) {
            if (Pattern.matches("^" + str + ".*", names[i].toUpperCase())) {
                System.out.println(names[i]);
            }
        }
    }
}
