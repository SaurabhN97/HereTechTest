var names = ["Mark Zuckerberg", "Will Smith", "William Gates", "Warren Buffet"];

function autocomplete(input, arr) {
    input.addEventListener("input", function (e) {
        var a, b, i, val = this.value;

        closeAllLists();

        if (!val) {
            return false;
        }

        a = document.createElement("DIV");
        a.setAttribute("class", "matchingNames")
        this.parentNode.appendChild(a);

        for (i = 0; i < arr.length; i++) {
            if (arr[i].substr(0, val.length).toUpperCase() == val.toUpperCase()) {
                b = document.createElement("div");
                b.innerHTML = arr[i];

                a.appendChild(b);
            }
        }
    });

    function closeAllLists(e) {
        var x = document.getElementsByClassName("matchingNames");
        for (var i = 0; i < x.length; i++) {
            if (e != x[i] && e != input) {
                x[i].parentNode.removeChild(x[i]);
            }
        }
    }
}



autocomplete(document.getElementById("name"), names);